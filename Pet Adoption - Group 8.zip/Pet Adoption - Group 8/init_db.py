#!/usr/bin/env python3
"""
Simple script to initialize the database with your schema.
Run: python init_db.py
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app, db
from models import User, Pet, Person, AdopterDetails, DonationDetailsUser, PetMedical, DonationDetailsPet, DonationPetMedical, AdopterRequest, DonationRequest, Message

def init_database():
    """Initialize the SQLite database with all tables."""
    
    # Remove existing database if you want fresh start
    db_file = 'instance/records.db'
    if os.path.exists(db_file):
        os.remove(db_file)
        print(f"Removed existing {db_file}")
    
    # Create all tables
    with app.app_context():
        db.create_all()
        
        print(f"\n✅ Database 'records.db' created successfully!")
        print(f"📁 Location: {os.path.abspath(db_file)}")
        
        # List all tables
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        tables = inspector.get_table_names()
        print(f"\n📊 Created {len(tables)} tables:")
        for table in tables:
            print(f"  - {table}")
        
        return True

def add_sample_data():
    """Add sample data to the database."""
    with app.app_context():
        print("\n📝 Adding sample data...")
        
        # Check if data already exists
        if User.query.filter_by(username='Admin1').first():
            print("Sample data already exists. Skipping...")
            return
        
        # 1. Create admin user
        admin = User(
            username='Admin1',
            password='adminpass',
            user_type='admin'
        )
        db.session.add(admin)
        
        # 2. Create regular users
        regular_users = [
            ('user1', 'password123'),
            ('user2', 'password123'),
            ('user3', 'password123'),
            ('user@gmail.com', '12345678')
        ]
        
        users = []
        for username, password in regular_users:
            user = User(
                username=username,
                password=password,
                user_type='regular'
            )
            db.session.add(user)
            users.append(user)
        
        # 3. Create sample persons (for adopters)
        persons = []
        person_data = [
            ('Jacey Hernandez', 28, '1234 Maple Street, Manila, Philippines', 'jacey.hernandez@email.com', '+639123456789'),
            ('Stephanie Sales', 32, '5678 Oak Avenue, Quezon City, Philippines', 'stephanie.sales@email.com', '+639178901234'),
            ('Megan Stuart', 25, '91011 Pine Road, Makati, Philippines', 'megan.stuart@email.com', '+639184567890'),
            ('Emily Brown', 31, '1819 Spruce Street, Pasig, Philippines', 'emily.brown@email.com', '+639223456789'),
            ('Robert Smith', 45, '2021 Redwood Drive, Mandaluyong, Philippines', 'robert.smith@email.com', '+639234567890'),
            ('Sarah Johnson', 28, '2223 Willow Road, Pasig, Philippines', 'sarah.johnson@email.com', '+639227890123')
        ]
        
        for full_name, age, address, email, phone in person_data:
            person = Person(
                full_name=full_name,
                age=age,
                address=address,
                email=email,
                phone_number=phone
            )
            db.session.add(person)
            persons.append(person)
        
        # 4. Create sample pets
        pets = []
        pet_data = [
            ('Leo', 'Cat', 6, 'M', 'Siamese', datetime.now() - timedelta(days=6*30)),
            ('Theo', 'Dog', 3, 'M', 'Corgi', datetime.now() - timedelta(days=3*30)),
            ('Hailey', 'Dog', 2, 'F', 'Maltese', datetime.now() - timedelta(days=2*30)),
            ('Bella', 'Cat', 12, 'F', 'Scottish Fold', datetime.now() - timedelta(days=12*30)),
            ('Max', 'Dog', 36, 'M', 'German Shepherd', datetime.now() - timedelta(days=36*30)),
            ('Luna', 'Cat', 18, 'F', 'British Shorthair', datetime.now() - timedelta(days=18*30))
        ]
        
        for name, type, age, gender, breed, bod in pet_data:
            pet = Pet(
                pet_name=name,
                pet_type=type,
                pet_age=age,
                pet_gender=gender,
                pet_breed=breed,
                pet_bod=bod
            )
            db.session.add(pet)
            pets.append(pet)
        
        db.session.flush()  # Get IDs for the created objects
        
        # 5. Add medical records for pets
        medical_records = []
        
        # Leo's medical records
        medical_records.append(PetMedical(
            pet_id=pets[0].pet_id,
            medical_type='Vaccine',
            name='FVRCP',
            date=datetime.now() - timedelta(days=90)
        ))
        medical_records.append(PetMedical(
            pet_id=pets[0].pet_id,
            medical_type='Deworming',
            name='Pyramid Pamoate',
            date=datetime.now() - timedelta(days=30)
        ))
        
        # Theo's medical records
        medical_records.append(PetMedical(
            pet_id=pets[1].pet_id,
            medical_type='Vaccine',
            name='DHPP',
            date=datetime.now() - timedelta(days=45)
        ))
        
        # Add all medical records
        for record in medical_records:
            db.session.add(record)
        
        # 6. Create sample adoption requests
        adoption_requests = []
        for i, (user, pet) in enumerate(zip(users[:3], pets[:3])):
            request = AdopterRequest(
                user_id=user.user_id,
                pet_id=pet.pet_id,
                status='Pending' if i == 0 else 'Approved' if i == 1 else 'Rejected'
            )
            db.session.add(request)
            adoption_requests.append(request)
        
        db.session.flush()
        
        # 7. Create adopter details
        for i, (request, person) in enumerate(zip(adoption_requests, persons[:3])):
            adopter_detail = AdopterDetails(
                adoption_id=request.adoption_id,
                person_id=person.person_id,
                employment_status='Employed Full-time',
                profession=['Software Engineer', 'Marketing Manager', 'Graphic Designer'][i],
                employment_history=['Tech Solutions Inc.', 'Creative Solutions Corp.', 'Design Studio Co.'][i]
            )
            db.session.add(adopter_detail)
        
        # 8. Create sample donation (rehoming) requests
        donation_requests = []
        for i, user in enumerate(users[3:]):
            request = DonationRequest(
                user_id=user.user_id,
                status='Pending' if i == 0 else 'Approved' if i == 1 else 'Rejected'
            )
            db.session.add(request)
            donation_requests.append(request)
        
        db.session.flush()
        
        # 9. Create donation details
        for i, (request, person) in enumerate(zip(donation_requests, persons[3:])):
            donation_detail = DonationDetailsUser(
                donation_id=request.donation_id,
                person_id=person.person_id
            )
            db.session.add(donation_detail)
        
        db.session.flush()
        
        # 10. Create donation pet details
        donation_details = DonationDetailsUser.query.all()
        for i, detail in enumerate(donation_details[:3]):
            donation_pet = DonationDetailsPet(
                donation_details_id=detail.donation_details_id,
                pet_id=pets[i+3].pet_id,
                adoption_reason=['Allergies in the family', 'Moving abroad', 'Financial constraints'][i]
            )
            db.session.add(donation_pet)
        
        # 11. Create sample messages
        messages = []
        
        # Adoption request messages
        for i, request in enumerate(adoption_requests):
            status = request.status
            pet = Pet.query.get(request.pet_id)
            user = User.query.get(request.user_id)
            
            if status == 'Pending':
                content = f'Your adoption request for {pet.pet_name} ({pet.pet_type}) is pending review.'
            elif status == 'Approved':
                content = f'Congratulations! Your adoption request for {pet.pet_name} ({pet.pet_type}) has been approved.'
            else:
                content = f'Your adoption request for {pet.pet_name} ({pet.pet_type}) has been rejected.'
            
            message = Message(
                adoption_id=request.adoption_id,
                content=content,
                message_type=f'Adoption {status}',
                is_sent=True,
                is_read=False
            )
            db.session.add(message)
        
        # Donation request messages
        for i, request in enumerate(donation_requests):
            status = request.status
            
            if status == 'Pending':
                content = 'Your rehoming request is pending review.'
            elif status == 'Approved':
                content = 'Your rehoming request has been approved.'
            else:
                content = 'Your rehoming request has been rejected.'
            
            message = Message(
                donation_id=request.donation_id,
                content=content,
                message_type=f'Rehoming {status}',
                is_sent=True,
                is_read=False
            )
            db.session.add(message)
        
        # Commit all changes
        db.session.commit()
        
        print("✅ Sample data added successfully!")
        print(f"  - Created {len(users)} users")
        print(f"  - Created {len(persons)} persons")
        print(f"  - Created {len(pets)} pets")
        print(f"  - Created {len(adoption_requests)} adoption requests")
        print(f"  - Created {len(donation_requests)} donation requests")
        print(f"  - Created {len(messages)} messages")

def clear_database():
    """Clear all data from the database."""
    with app.app_context():
        print("\n⚠️ Clearing all data from database...")
        
        # Delete all data from all tables (in correct order to avoid foreign key constraints)
        Message.query.delete()
        DonationPetMedical.query.delete()
        DonationDetailsPet.query.delete()
        DonationDetailsUser.query.delete()
        AdopterDetails.query.delete()
        PetMedical.query.delete()
        AdopterRequest.query.delete()
        DonationRequest.query.delete()
        Pet.query.delete()
        Person.query.delete()
        User.query.delete()
        
        db.session.commit()
        print("✅ Database cleared successfully!")

def main():
    """Main function to run the database initialization."""
    print("=" * 50)
    print("BESTO FRIENDO - Database Initialization")
    print("=" * 50)
    
    # Initialize the database
    if init_database():
        # Ask user what they want to do
        print("\nChoose an option:")
        print("1. Initialize database with sample data")
        print("2. Clear all data from database")
        print("3. Just create empty tables")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            add_sample_data()
        elif choice == '2':
            clear_database()
        elif choice == '3':
            print("✅ Empty tables created successfully!")
        elif choice == '4':
            print("Exiting...")
        else:
            print("❌ Invalid choice. Exiting...")
    
    print("\n" + "=" * 50)
    print("Database initialization complete!")
    print("=" * 50)

if __name__ == '__main__':
    main()