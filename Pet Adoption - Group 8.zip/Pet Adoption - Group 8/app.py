#!/usr/bin/env python3
"""
Main Flask application for BESTO FRIENDO.
"""

from flask import Flask, render_template, url_for, request, redirect, session, flash, jsonify
import os
import json
from datetime import datetime, timedelta

# Import database models
from models import db, User, Pet, Person, AdopterDetails, DonationDetailsUser, PetMedical, DonationDetailsPet, DonationPetMedical, AdopterRequest, DonationRequest, Message

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///records.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database with app
db.init_app(app)

# Hardcoded admin credentials for backward compatibility
ADMIN_USERNAME = "Admin1"
ADMIN_PASSWORD = "adminpass"

# Hardcoded user credentials (for demo purposes - backward compatibility)
USER_CREDENTIALS = {
    "user1": "password123",
    "user2": "password123",
    "user3": "password123",
    "user@gmail.com": "12345678"
}

# ALL PETS DATA - Used in index, user_adopt, and user_rehome (backward compatibility)
ALL_PETS_DATA = [
    {
        'name': 'Leo',
        'type': 'Cat',
        'age': '6 months old',
        'breed': 'Siamese',
        'sex': 'Male',
        'location': 'Manila, Philippines',
        'image': 'leo_cat.png',
        'age_months': 6,
        'key': 'leo',
        'description': 'Beautiful Siamese cat looking for a loving family.'
    },
    {
        'name': 'Theo',
        'type': 'Dog',
        'age': '3 months old',
        'breed': 'Corgi',
        'sex': 'Male',
        'location': 'Quezon City, Philippines',
        'image': 'theo_dog.png',
        'age_months': 3,
        'key': 'theo',
        'description': 'Playful Corgi puppy ready for adventures.'
    },
    {
        'name': 'Hailey',
        'type': 'Dog',
        'age': '2 months old',
        'breed': 'Maltese',
        'sex': 'Female',
        'location': 'Makati, Philippines',
        'image': 'hailey_dog.png',
        'age_months': 2,
        'key': 'hailey',
        'description': 'Sweet Maltese puppy looking for a caring home.'
    },
    {
        'name': 'Bella',
        'type': 'Cat',
        'age': '1 year old',
        'breed': 'Scottish Fold',
        'sex': 'Female',
        'location': 'Pasig, Philippines',
        'image': 'bella1.png',
        'age_months': 12,
        'key': 'bella',
        'description': 'Gentle Scottish Fold cat with folded ears.'
    },
    {
        'name': 'Max',
        'type': 'Dog',
        'age': '3 years old',
        'breed': 'German Shepherd',
        'sex': 'Male',
        'location': 'Mandaluyong, Philippines',
        'image': 'max1.png',
        'age_months': 36,
        'key': 'max',
        'description': 'Loyal and protective German Shepherd.'
    },
    {
        'name': 'Luna',
        'type': 'Cat',
        'age': '1.5 years old',
        'breed': 'British Shorthair',
        'sex': 'Female',
        'location': 'Pasig, Philippines',
        'image': 'luna1.png',
        'age_months': 18,
        'key': 'luna',
        'description': 'Calm British Shorthair with plush fur.'
    }
]

# Sample data for requests - ONLY 3 ENTRIES EACH (backward compatibility)
ADOPTION_REQUESTS = [
    {'name': 'Jacey Hernandez', 'date': 'Dec 8, 2025', 'status': 'Pending', 'new': True, 'pet_key': 'jacey', 'pet_name': 'Leo', 'pet_type': 'Cat'},
    {'name': 'Stephanie Sales', 'date': 'Dec 6, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'stephanie', 'pet_name': 'Theo', 'pet_type': 'Dog'},
    {'name': 'Megan Stuart', 'date': 'Dec 5, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'megan', 'pet_name': 'Hailey', 'pet_type': 'Dog'},
]

REHOMING_REQUESTS = [
    {'name': 'Emily Brown', 'date': 'Dec 7, 2025', 'status': 'Pending', 'new': True, 'pet_key': 'emily', 'pet_name': 'Bella', 'pet_type': 'Cat'},
    {'name': 'Robert Smith', 'date': 'Dec 5, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'robert', 'pet_name': 'Max', 'pet_type': 'Dog'},
    {'name': 'Sarah Johnson', 'date': 'Dec 4, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'sarah', 'pet_name': 'Luna', 'pet_type': 'Cat'},
]

# Pet details data (backward compatibility)
PET_DATA = {
    'leo': {
        'title': "Want to Adopt:",
        'name': "Leo",
        'type': "Cat",
        'age': "6 months old",
        'gender': "M",
        'breed': "Siamese",
        'birthday': "06/15/2025",
        'vaccineType': "FVRCP",
        'firstVaccine': "09/01/2025",
        'latestVaccine': "12/01/2025",
        'dewormerType': "Pyramid Pamoate",
        'firstDeworming': "08/01/2025",
        'latestDeworming': "11/01/2025",
        'reason': "Allergies in the family",
        'images': ['leo_cat.png', 'leo2.png', 'leo3.png', 'leo4.png'],
        'owner': {
            'name': "Jacey Hernandez",
            'age': "28",
            'address': "1234 Maple Street, Manila, Philippines",
            'email': "jacey.hernandez@email.com",
            'contact': "+63 912 345 6789"
        }
    },
    'theo': {
        'title': "Want to Adopt:",
        'name': "Theo",
        'type': "Dog",
        'age': "3 months old",
        'gender': "M",
        'breed': "Corgi",
        'birthday': "09/10/2025",
        'vaccineType': "DHPP",
        'firstVaccine': "10/15/2025",
        'latestVaccine': "12/05/2025",
        'dewormerType': "Fenbendazole",
        'firstDeworming': "10/01/2025",
        'latestDeworming': "11/25/2025",
        'reason': "Moving to a pet-free apartment",
        'images': ['theo_dog.png', 'theo2.png', 'theo3.png', 'theo4.png'],
        'owner': {
            'name': "Stephanie Sales",
            'age': "32",
            'address': "5678 Oak Avenue, Quezon City, Philippines",
            'email': "stephanie.sales@email.com",
            'contact': "+63 917 890 1234"
        }
    },
    'hailey': {
        'title': "Want to Adopt:",
        'name': "Hailey",
        'type': "Dog",
        'age': "2 months old",
        'gender': "F",
        'breed': "Maltese",
        'birthday': "10/05/2025",
        'vaccineType': "DHPP",
        'firstVaccine': "11/10/2025",
        'latestVaccine': "12/08/2025",
        'dewormerType': "Pyrantel Pamoate",
        'firstDeworming': "11/01/2025",
        'latestDeworming': "12/01/2025",
        'reason': "Financial constraints",
        'images': ['hailey_dog.png', 'hailey2.png', 'hailey3.png', 'hailey4.png'],
        'owner': {
            'name': "Megan Stuart",
            'age': "25",
            'address': "91011 Pine Road, Makati, Philippines",
            'email': "megan.stuart@email.com",
            'contact': "+63 918 456 7890"
        }
    },
    'bella': {
        'title': "Want to Adopt:",
        'name': "Bella",
        'type': "Cat",
        'age': "1 year old",
        'gender': "F",
        'breed': "Scottish Fold",
        'birthday': "12/10/2024",
        'vaccineType': "FVRCP",
        'firstVaccine': "02/15/2025",
        'latestVaccine': "11/20/2025",
        'dewormerType': "Pyramid Pamoate",
        'firstDeworming': "01/20/2025",
        'latestDeworming': "10/15/2025",
        'reason': "Owner traveling frequently for work",
        'images': ['bella1.png', 'bella2.png', 'bella3.png', 'bella4.png'],
        'owner': {
            'name': "Emily Brown",
            'age': "31",
            'address': "1819 Spruce Street, Pasig, Philippines",
            'email': "emily.brown@email.com",
            'contact': "+63 922 345 6789"
        }
    },
    'max': {
        'title': "Want to Adopt:",
        'name': "Max",
        'type': "Dog",
        'age': "3 years old",
        'gender': "M",
        'breed': "German Shepherd",
        'birthday': "11/15/2022",
        'vaccineType': "DHPP",
        'firstVaccine': "01/20/2023",
        'latestVaccine': "10/25/2025",
        'dewormerType': "Fenbendazole",
        'firstDeworming': "12/20/2022",
        'latestDeworming': "09/30/2025",
        'reason': "Owner relocating to a smaller home",
        'images': ['max1.png', 'max2.png', 'max3.png', 'max4.png'],
        'owner': {
            'name': "Robert Smith",
            'age': "45",
            'address': "2021 Redwood Drive, Mandaluyong, Philippines",
            'email': "robert.smith@email.com",
            'contact': "+63 923 456 7890"
        }
    },
    'luna': {
        'title': "Want to Adopt:",
        'name': "Luna",
        'type': "Cat",
        'age': "1.5 years old",
        'gender': "F",
        'breed': "British Shorthair",
        'birthday': "06/15/2024",
        'vaccineType': "FVRCP",
        'firstVaccine': "08/01/2024",
        'latestVaccine': "11/15/2025",
        'dewormerType': "Pyrantel Pamoate",
        'firstDeworming': "07/15/2024",
        'latestDeworming': "10/30/2025",
        'reason': "Owner moving abroad",
        'images': ['luna1.png', 'luna2.png', 'luna3.png', 'luna4.png'],
        'owner': {
            'name': "Sarah Johnson",
            'age': "28",
            'address': "2223 Willow Road, Pasig, Philippines",
            'email': "sarah.johnson@email.com",
            'contact': "+63 922 789 0123"
        }
    }
}

# Additional pets for View Pets page (backward compatibility)
ADDITIONAL_PETS = {
    'lia': {'name': "Lia", 'type': "Cat", 'breed': "Ragdoll", 'age': "8 months old"},
    'kabel': {'name': "Kabel", 'type': "Cat", 'breed': "Puspin", 'age': "1 year old"},
    'znowy': {'name': "Znowy", 'type': "Cat", 'breed': "Ragdoll", 'age': "9 months old"},
    'oreo': {'name': "Oreo", 'type': "Cat", 'breed': "Siamese", 'age': "2 years old"},
    'asher': {'name': "Asher", 'type': "Cat", 'breed': "Puspin", 'age': "1.5 years old"}
}

# Adopter details data (backward compatibility)
ADOPTER_DATA = {
    'jacey': {
        'name': "Jacey Hernandez",
        'age': "28 years old",
        'address': "1234 Maple Street, Manila, Philippines",
        'email': "jacey.hernandez@email.com",
        'contact': "+63 912 345 6789",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Software Engineer",
        'employer': "Tech Solutions Inc.",
        'idType': "Driver's License"
    },
    'stephanie': {
        'name': "Stephanie Sales",
        'age': "32 years old",
        'address': "5678 Oak Avenue, Quezon City, Philippines",
        'email': "stephanie.sales@email.com",
        'contact': "+63 917 890 1234",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Marketing Manager",
        'employer': "Creative Solutions Corp.",
        'idType': "Passport"
    },
    'megan': {
        'name': "Megan Stuart",
        'age': "25 years old",
        'address': "91011 Pine Road, Makati, Philippines",
        'email': "megan.stuart@email.com",
        'contact': "+63 918 456 7890",
        'employmentStatus': "Employed Part-time",
        'jobTitle': "Graphic Designer",
        'employer': "Design Studio Co.",
        'idType': "Driver's License"
    },
    'emily': {
        'name': "Emily Brown",
        'age': "31 years old",
        'address': "1819 Spruce Street, Pasig, Philippines",
        'email': "emily.brown@email.com",
        'contact': "+63 922 345 6789",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Flight Attendant",
        'employer': "Sky Airlines",
        'idType': "Passport"
    },
    'robert': {
        'name': "Robert Smith",
        'age': "45 years old",
        'address': "2021 Redwood Drive, Mandaluyong, Philippines",
        'email': "robert.smith@email.com",
        'contact': "+63 923 456 7890",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Architect",
        'employer': "Urban Design Associates",
        'idType': "Professional ID"
    },
    'sarah': {
        'name': "Sarah Johnson",
        'age': "28 years old",
        'address': "2223 Willow Road, Pasig, Philippines",
        'email': "sarah.johnson@email.com",
        'contact': "+63 922 789 0123",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Marketing Director",
        'employer': "Digital Marketing Inc.",
        'idType': "Driver's License"
    }
}

# Global lists for backward compatibility
USER_REQUESTS = {}
APPROVED_REQUESTS = []
REJECTED_REQUESTS = []

# ============================================================================
# ROUTES
# ============================================================================

@app.route('/')
def home():
    return render_template('index.html', pets=ALL_PETS_DATA)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        # Try to authenticate with database first
        user = User.query.filter_by(username=username, password=password).first()
        
        if user:
            if user.user_type == 'admin':
                session['admin_logged_in'] = True
                session['username'] = username
                session['user_id'] = user.user_id
                return redirect(url_for('admin_panel'))
            else:
                session['user_logged_in'] = True
                session['username'] = username
                session['user_id'] = user.user_id
                return redirect(url_for('user_adopt'))
        # Fallback to hardcoded credentials for backward compatibility
        elif username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            session['username'] = username
            return redirect(url_for('admin_panel'))
        elif username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            session['user_logged_in'] = True
            session['username'] = username
            return redirect(url_for('user_adopt'))
        else:
            flash('Invalid username or password')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Basic validation
        if not username or not password:
            flash('Please fill in all fields')
            return redirect(url_for('signup'))
        
        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('signup'))
        
        if len(password) < 7:
            flash('Password must be at least 7 characters long')
            return redirect(url_for('signup'))
        
        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose another.')
            return redirect(url_for('signup'))
        
        # Create new user
        try:
            new_user = User(
                username=username,
                password=password,
                user_type='regular'  # Default to regular user
            )
            db.session.add(new_user)
            db.session.commit()
            
            # Get the user_id after commit
            user_id = new_user.user_id
            
            # DIRECTLY LOG IN THE USER AND REDIRECT TO USER PANEL
            session['user_logged_in'] = True
            session['username'] = username
            session['user_id'] = user_id
            
            flash('Account created successfully! Welcome to BESTO FRIENDO.')
            return redirect(url_for('user_adopt'))  # Directly go to user panel
        
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.')
            print(f"Error creating user: {str(e)}")
            return redirect(url_for('signup'))
    
    return render_template('signup.html')

@app.route('/admin-logout')
def admin_logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/user-logout')
def user_logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/admin-panel')
def admin_panel():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    # Get data from database for stats
    total_pets = Pet.query.count()
    adoption_requests_count = AdopterRequest.query.filter_by(status='Pending').count()
    donation_requests_count = DonationRequest.query.filter_by(status='Pending').count()
    total_users = User.query.count()
    
    # Get pending adoption requests for display
    pending_adoption_requests = AdopterRequest.query.filter_by(status='Pending').all()
    adoption_requests_list = []
    
    for req in pending_adoption_requests:
        user = User.query.get(req.user_id)
        pet = Pet.query.get(req.pet_id)
        adopter_detail = AdopterDetails.query.filter_by(adoption_id=req.adoption_id).first()
        person = Person.query.get(adopter_detail.person_id) if adopter_detail else None
        
        if pet and person:
            adoption_requests_list.append({
                'name': person.full_name,
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'status': req.status,
                'new': True,  # You can customize this logic
                'pet_key': str(pet.pet_id),
                'pet_name': pet.pet_name,
                'pet_type': pet.pet_type
            })
    
    # Get pending rehoming requests for display
    pending_rehoming_requests = DonationRequest.query.filter_by(status='Pending').all()
    rehoming_requests_list = []
    
    for req in pending_rehoming_requests:
        user = User.query.get(req.user_id)
        donation_detail = DonationDetailsUser.query.filter_by(donation_id=req.donation_id).first()
        person = Person.query.get(donation_detail.person_id) if donation_detail else None
        
        # Get the first pet from donation
        donation_pets = DonationDetailsPet.query.filter_by(donation_details_id=donation_detail.donation_details_id).all() if donation_detail else []
        first_pet = Pet.query.get(donation_pets[0].pet_id) if donation_pets else None
        
        if person:
            rehoming_requests_list.append({
                'name': person.full_name,
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'status': req.status,
                'new': True,  # You can customize this logic
                'pet_key': str(req.donation_id),  # Use donation_id as key for rehoming
                'pet_name': first_pet.pet_name if first_pet else 'Multiple Pets',
                'pet_type': first_pet.pet_type if first_pet else 'Various'
            })
    
    # Prepare pet data for JSON (for backward compatibility)
    pet_data_for_json = {}
    all_pets = Pet.query.all()
    for pet in all_pets:
        # Get medical records
        vaccines = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Vaccine').all()
        deworming = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Deworming').all()
        
        # Get adoption reason if this pet is in an adoption request
        adoption_request = AdopterRequest.query.filter_by(pet_id=pet.pet_id).first()
        adopter_detail = AdopterDetails.query.filter_by(adoption_id=adoption_request.adoption_id).first() if adoption_request else None
        person = Person.query.get(adopter_detail.person_id) if adopter_detail else None
        
        pet_data_for_json[str(pet.pet_id)] = {
            'title': "Want to Adopt:",
            'name': pet.pet_name,
            'type': pet.pet_type,
            'age': f"{pet.pet_age} months old" if pet.pet_age else "Unknown",
            'gender': pet.pet_gender,
            'breed': pet.pet_breed,
            'birthday': pet.pet_bod.strftime('%m/%d/%Y') if pet.pet_bod else 'Unknown',
            'vaccineType': vaccines[0].name if vaccines else 'Not specified',
            'firstVaccine': vaccines[0].date.strftime('%m/%d/%Y') if vaccines else 'Not specified',
            'latestVaccine': vaccines[-1].date.strftime('%m/%d/%Y') if vaccines else 'Not specified',
            'dewormerType': deworming[0].name if deworming else 'Not specified',
            'firstDeworming': deworming[0].date.strftime('%m/%d/%Y') if deworming else 'Not specified',
            'latestDeworming': deworming[-1].date.strftime('%m/%d/%Y') if deworming else 'Not specified',
            'reason': adoption_request.status if adoption_request else 'Available for adoption',
            'images': ['default_pet.png'],  # Default image - you can store image names in database
            'owner': {
                'name': person.full_name if person else 'Unknown',
                'age': f"{person.age} years old" if person else 'Unknown',
                'address': person.address if person else 'Unknown',
                'email': person.email if person else 'Unknown',
                'contact': person.phone_number if person else 'Unknown'
            } if person else None
        }
    
    # Prepare adopter data for JSON (for backward compatibility)
    adopter_data_for_json = {}
    all_adopter_details = AdopterDetails.query.all()
    for detail in all_adopter_details:
        person = Person.query.get(detail.person_id)
        if person:
            adopter_data_for_json[str(detail.adopter_details_id)] = {
                'name': person.full_name,
                'age': f"{person.age} years old",
                'address': person.address,
                'email': person.email,
                'contact': person.phone_number,
                'employmentStatus': detail.employment_status,
                'jobTitle': detail.profession,
                'employer': detail.employment_history,
                'idType': 'Government ID'  # Default - you can add this field to database
            }
    
    return render_template('admin_panel.html', 
                         adoption_requests=adoption_requests_list[:3] if adoption_requests_list else ADOPTION_REQUESTS,
                         rehoming_requests=rehoming_requests_list[:3] if rehoming_requests_list else REHOMING_REQUESTS,
                         pet_data=json.dumps(pet_data_for_json),
                         adopter_data=json.dumps(adopter_data_for_json),
                         total_pets=total_pets,
                         adoption_requests_count=adoption_requests_count,
                         donation_requests_count=donation_requests_count,
                         total_users=total_users)

@app.route('/user-panel')
def user_panel():
    # Check if user is logged in
    if not session.get('user_logged_in'):
        return redirect(url_for('login'))
    
    # Redirect to the adopt section
    return redirect(url_for('user_adopt'))

@app.route('/user-adopt')
def user_adopt():
    if not session.get('user_logged_in'):
        return redirect(url_for('login'))
    
    # Get available pets from database
    pets_from_db = Pet.query.all()
    
    return render_template('user_adopt.html', pets=ALL_PETS_DATA)

@app.route('/user-rehome')
def user_rehome():
    if not session.get('user_logged_in'):
        return redirect(url_for('login'))
    
    return render_template('user_rehome.html', pets=ALL_PETS_DATA)

@app.route('/submit-rehoming', methods=['GET', 'POST'])
def submit_rehoming():
    # If the user tries to access the link manually (GET), redirect them back
    if request.method == 'GET':
        return redirect(url_for('user_rehome'))

    try:
        # Check if user is logged in
        username = session.get('username')
        if not username:
             return jsonify({'success': False, 'error': 'Not logged in'}), 401
             
        # ... your database logic here ...
        
        db.session.commit()
        return jsonify({'success': True})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
        
        # Get form data
        form_data = request.form
        
        # 1. Create or update Person record
        person = Person.query.filter_by(email=form_data.get('rehomer_email')).first()
        if not person:
            person = Person(
                full_name=form_data.get('rehomer_name') or session.get('username'),
                age=int(form_data.get('rehomer_age')) if form_data.get('rehomer_age') else 0, # Fallback to 0
                address=form_data.get('rehomer_address') or "Not Provided",
                email=form_data.get('rehomer_email'),
                phone_number=form_data.get('rehomer_phone')
)
            db.session.add(person)
            db.session.flush()
        else:
            # Update existing person
            person.age = int(form_data.get('rehomer_age')) if form_data.get('rehomer_age') else None
            person.address = form_data.get('rehomer_address')
            person.phone_number = form_data.get('rehomer_phone')
        
        # 2. Handle ID images
        id_front = request.files.get('id_front')
        if id_front:
            person.valid_image = id_front.read()
        
        # 3. Create Pet record
        pet_birthday = None
        if form_data.get('pet_birthday'):
            try:
                pet_birthday = datetime.strptime(form_data.get('pet_birthday'), '%Y-%m-%d').date()
            except ValueError:
                pass
        
        pet = Pet(
            pet_name=form_data.get('pet_name'),
            pet_type=form_data.get('pet_type'),
            pet_age=int(form_data.get('pet_age')) if form_data.get('pet_age') else None,
            pet_gender=form_data.get('pet_sex'),
            pet_breed=form_data.get('pet_breed'),
            pet_bod=pet_birthday
        )
        db.session.add(pet)
        db.session.flush()
        
        # 4. Create medical records (vaccines)
        if form_data.get('vaccine_type') and form_data.get('first_vaccine_date'):
            try:
                first_vaccine_date = datetime.strptime(form_data.get('first_vaccine_date'), '%Y-%m-%d').date()
                PetMedical(
                    pet_id=pet.pet_id,
                    medical_type='vaccine',
                    name=form_data.get('vaccine_type'),
                    date=first_vaccine_date
                ).save()
            except ValueError:
                pass
        
        # 5. Create DonationRequest
        donation_request = DonationRequest(
            user_id=user.user_id,
            status='Pending',
            request_date=datetime.utcnow()
        )
        db.session.add(donation_request)
        db.session.flush()
        
        # 6. Create DonationDetailsUser
        donation_details_user = DonationDetailsUser(
            donation_id=donation_request.donation_id,
            person_id=person.person_id
        )
        db.session.add(donation_details_user)
        db.session.flush()
        
        # 7. Create DonationDetailsPet
        donation_details_pet = DonationDetailsPet(
            donation_details_id=donation_details_user.donation_details_id,
            pet_id=pet.pet_id,
            adoption_reason=form_data.get('reason')
        )
        db.session.add(donation_details_pet)
        
        # 8. Create message
        message = Message(
            donation_id=donation_request.donation_id,
            content=f"Your rehoming request for {pet.pet_name} has been received.",
            message_type='Info',
            sent_date=datetime.utcnow(),
            is_sent=True
        )
        db.session.add(message)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Rehoming request submitted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/user-messages')
def user_messages():
    if not session.get('user_logged_in'):
        return redirect(url_for('login'))
    
    username = session.get('username')
    user_id = session.get('user_id')
    
    # Get messages for this user from database
    # Messages related to adoption requests
    adoption_messages = []
    user_adoption_requests = AdopterRequest.query.filter_by(user_id=user_id).all()
    for adoption_request in user_adoption_requests:
        messages = Message.query.filter_by(adoption_id=adoption_request.adoption_id, is_sent=True).all()
        for msg in messages:
            adoption_messages.append({
                'id': msg.message_id,
                'recipient': username,
                'type': 'Adoption Update',
                'pet_name': adoption_request.pet.pet_name if adoption_request.pet else 'Unknown',
                'pet_type': adoption_request.pet.pet_type if adoption_request.pet else 'Unknown',
                'status': adoption_request.status,
                'status_color': '#58CE46' if adoption_request.status == 'Approved' else '#ff4444' if adoption_request.status == 'Rejected' else '#ff9800',
                'date': msg.sent_date.strftime('%b %d, %Y') if msg.sent_date else 'Unknown',
                'content': msg.content,
                'message_sent': msg.is_sent
            })
    
    # Messages related to donation requests
    donation_messages = []
    user_donation_requests = DonationRequest.query.filter_by(user_id=user_id).all()
    for donation_request in user_donation_requests:
        messages = Message.query.filter_by(donation_id=donation_request.donation_id, is_sent=True).all()
        for msg in messages:
            donation_messages.append({
                'id': msg.message_id,
                'recipient': username,
                'type': 'Rehoming Update',
                'pet_name': 'Multiple Pets' if donation_request.donation_details_users else 'No Pet',
                'pet_type': 'Various',
                'status': donation_request.status,
                'status_color': '#58CE46' if donation_request.status == 'Approved' else '#ff4444' if donation_request.status == 'Rejected' else '#ff9800',
                'date': msg.sent_date.strftime('%b %d, %Y') if msg.sent_date else 'Unknown',
                'content': msg.content,
                'message_sent': msg.is_sent
            })
    
    all_messages = adoption_messages + donation_messages
    
    if not all_messages:
        # If no real messages, show welcome message
        all_messages = [{
            'id': 1,
            'recipient': username,
            'type': 'Welcome Message',
            'pet_name': 'No Pet',
            'pet_type': 'System',
            'status': 'Info',
            'status_color': '#34325D',
            'date': datetime.now().strftime('%b %d, %Y'),
            'content': 'Welcome to BESTO FRIENDO! Start by browsing pets for adoption or submitting a rehoming request.',
            'message_sent': True
        }]
    
    return render_template('user_messages.html', messages=all_messages)

@app.route('/submit-adoption', methods=['POST'])
def submit_adoption():
    if not session.get('user_logged_in'):
        return jsonify({'success': False, 'error': 'Not logged in'})
    
    try:
        data = request.get_json()
        user_id = session.get('user_id')
        pet_name = data.get('pet_name')
        pet_type = data.get('pet_type')
        
        # Find the pet in database
        pet = Pet.query.filter_by(pet_name=pet_name, pet_type=pet_type).first()
        if not pet:
            return jsonify({'success': False, 'error': 'Pet not found'})
        
        # Create adoption request in database
        adoption_request = AdopterRequest(
            user_id=user_id,
            pet_id=pet.pet_id,
            status='Pending'
        )
        db.session.add(adoption_request)
        db.session.commit()
        
        # Create a message for the user
        message = Message(
            adoption_id=adoption_request.adoption_id,
            content=f'Your adoption request for {pet_name} ({pet_type}) has been received and is under review.',
            message_type='Adoption Request',
            is_sent=True,
            is_read=False
        )
        db.session.add(message)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Adoption request submitted successfully!'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})


@app.route('/view-pets')
def view_pets():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    # Get all pets from database
    pets_from_db = Pet.query.all()
    pets_list = []
    
    for pet in pets_from_db:
        # Determine gender display
        if pet.pet_gender == 'M':
            gender = 'Male'
        elif pet.pet_gender == 'F':
            gender = 'Female'
        else:
            gender = 'Unknown'
        
        # Get adoption status
        adoption_request = AdopterRequest.query.filter_by(pet_id=pet.pet_id).first()
        if adoption_request:
            status = adoption_request.status
        else:
            status = 'Available'
        
        # Get owner info if adopted
        owner_info = None
        if adoption_request and adoption_request.status == 'Approved':
            adopter_detail = AdopterDetails.query.filter_by(adoption_id=adoption_request.adoption_id).first()
            if adopter_detail:
                person = Person.query.get(adopter_detail.person_id)
                if person:
                    owner_info = {
                        'name': person.full_name,
                        'age': f"{person.age} years old",
                        'address': person.address,
                        'email': person.email,
                        'contact': person.phone_number
                    }
        
        # Get medical records
        vaccines = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Vaccine').all()
        deworming = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Deworming').all()
        
        # Create pet entry
        pet_entry = {
            'key': str(pet.pet_id),
            'name': pet.pet_name,
            'type': pet.pet_type,
            'breed': pet.pet_breed,
            'age': f"{pet.pet_age} months" if pet.pet_age else "Unknown",
            'gender': gender,
            'sex': gender,  # For backward compatibility
            'location': 'Not specified',
            'description': f"{pet.pet_type} available for adoption",
            'status': status,
            'birthday': pet.pet_bod.strftime('%m/%d/%Y') if pet.pet_bod else 'Unknown',
            'owner': owner_info
        }
        
        # Add medical records if available
        if vaccines:
            pet_entry['vaccineType'] = vaccines[0].name if vaccines else 'Not specified'
            pet_entry['firstVaccine'] = vaccines[0].date.strftime('%m/%d/%Y') if vaccines else 'Not specified'
            pet_entry['latestVaccine'] = vaccines[-1].date.strftime('%m/%d/%Y') if vaccines else 'Not specified'
        
        if deworming:
            pet_entry['dewormerType'] = deworming[0].name if deworming else 'Not specified'
            pet_entry['firstDeworming'] = deworming[0].date.strftime('%m/%d/%Y') if deworming else 'Not specified'
            pet_entry['latestDeworming'] = deworming[-1].date.strftime('%m/%d/%Y') if deworming else 'Not specified'
        
        # Add reason if there's an adoption request
        if adoption_request:
            adopter_detail = AdopterDetails.query.filter_by(adoption_id=adoption_request.adoption_id).first()
            if adopter_detail:
                person = Person.query.get(adopter_detail.person_id)
                if person:
                    pet_entry['reason'] = f"Adoption request from {person.full_name}"
        
        pets_list.append(pet_entry)
    
    return render_template('view_pets.html', pets=pets_list)

@app.route('/compose')
def compose():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    # Get pending requests from database
    pending_adoptions = AdopterRequest.query.filter_by(status='Pending').all()
    pending_donations = DonationRequest.query.filter_by(status='Pending').all()
    
    # Convert to list for template
    adoption_requests_list = []
    for req in pending_adoptions:
        user = User.query.get(req.user_id)
        pet = Pet.query.get(req.pet_id)
        adoption_requests_list.append({
            'name': user.username if user else 'Unknown',
            'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
            'status': req.status,
            'new': True,
            'pet_key': str(req.pet_id),
            'pet_name': pet.pet_name if pet else 'Unknown',
            'pet_type': pet.pet_type if pet else 'Unknown',
            'request_type': 'adoption',
            'original_index': req.adoption_id
        })
    
    donation_requests_list = []
    for req in pending_donations:
        user = User.query.get(req.user_id)
        donation_requests_list.append({
            'name': user.username if user else 'Unknown',
            'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
            'status': req.status,
            'new': True,
            'pet_key': 'donation_' + str(req.donation_id),
            'pet_name': 'Multiple Pets',
            'pet_type': 'Various',
            'request_type': 'rehoming',
            'original_index': req.donation_id
        })
    
    return render_template('compose.html', 
                         approved_requests=APPROVED_REQUESTS,
                         rejected_requests=REJECTED_REQUESTS,
                         adoption_requests=adoption_requests_list,
                         rehoming_requests=donation_requests_list)

@app.route('/update-request-status', methods=['POST'])
def update_request_status():
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'error': 'Not authorized'})
    
    data = request.get_json()
    request_type = data.get('type')  # 'adoption' or 'rehoming'
    request_index = int(data.get('index'))
    status = data.get('status')  # 'accepted' or 'rejected'
    pet_key = data.get('pet_key')
    requester_name = data.get('requester_name')
    
    try:
        if request_type == 'adoption':
            # Find the adoption request in database
            adoption_request = AdopterRequest.query.get(request_index)
            if adoption_request:
                adoption_request.status = status.capitalize()
                adoption_request.processed_date = datetime.utcnow()
                
                # Update pet status if adopted
                if status == 'accepted':
                    pet = Pet.query.get(adoption_request.pet_id)
                    if pet:
                        # You might want to mark pet as adopted
                        pass
                
                # Create message record in database (not sent yet)
                pet = Pet.query.get(adoption_request.pet_id)
                message_type = f'Adoption {"Approval" if status == "accepted" else "Rejection"}'
                message = Message(
                    adoption_id=adoption_request.adoption_id,
                    content='',  # Will be filled when message is actually sent
                    message_type=message_type,
                    is_sent=False,  # Track if message was actually sent from Compose
                    is_read=False
                )
                db.session.add(message)
                db.session.commit()
                
                return jsonify({'success': True, 'message': f'Adoption request {status}'})
        
        elif request_type == 'rehoming':
            # Find the donation request in database
            donation_request = DonationRequest.query.get(request_index)
            if donation_request:
                donation_request.status = status.capitalize()
                donation_request.processed_date = datetime.utcnow()
                
                # Create message record in database (not sent yet)
                message_type = f'Rehoming {"Approval" if status == "accepted" else "Rejection"}'
                message = Message(
                    donation_id=donation_request.donation_id,
                    content='',  # Will be filled when message is actually sent
                    message_type=message_type,
                    is_sent=False,  # Track if message was actually sent from Compose
                    is_read=False
                )
                db.session.add(message)
                db.session.commit()
                
                return jsonify({'success': True, 'message': f'Rehoming request {status}'})
        
        return jsonify({'success': False, 'error': 'Request not found'})
    
    except Exception as e:
        db.session.rollback()
        print(f"Error updating request status: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get-approved-requests')
def get_approved_requests():
    try:
        # Get approved requests from database
        approved_adoptions = AdopterRequest.query.filter_by(status='Approved').all()
        approved_donations = DonationRequest.query.filter_by(status='Approved').all()
        
        approved_list = []
        for req in approved_adoptions:
            user = User.query.get(req.user_id)
            pet = Pet.query.get(req.pet_id)
            approved_list.append({
                'type': 'adoption',
                'name': user.username if user else 'Unknown',
                'pet_name': pet.pet_name if pet else 'Unknown',
                'pet_type': pet.pet_type if pet else 'Unknown',
                'status': 'Approved',
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'original_index': req.adoption_id
            })
        
        for req in approved_donations:
            user = User.query.get(req.user_id)
            approved_list.append({
                'type': 'rehoming',
                'name': user.username if user else 'Unknown',
                'pet_name': 'Multiple Pets',
                'pet_type': 'Various',
                'status': 'Approved',
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'original_index': req.donation_id
            })
        
        return jsonify(approved_list)
    except Exception as e:
        print(f"Error getting approved requests: {str(e)}")
        return jsonify([])

@app.route('/get-rejected-requests')
def get_rejected_requests():
    try:
        # Get rejected requests from database
        rejected_adoptions = AdopterRequest.query.filter_by(status='Rejected').all()
        rejected_donations = DonationRequest.query.filter_by(status='Rejected').all()
        
        rejected_list = []
        for req in rejected_adoptions:
            user = User.query.get(req.user_id)
            pet = Pet.query.get(req.pet_id)
            rejected_list.append({
                'type': 'adoption',
                'name': user.username if user else 'Unknown',
                'pet_name': pet.pet_name if pet else 'Unknown',
                'pet_type': pet.pet_type if pet else 'Unknown',
                'status': 'Rejected',
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'original_index': req.adoption_id
            })
        
        for req in rejected_donations:
            user = User.query.get(req.user_id)
            rejected_list.append({
                'type': 'rehoming',
                'name': user.username if user else 'Unknown',
                'pet_name': 'Multiple Pets',
                'pet_type': 'Various',
                'status': 'Rejected',
                'date': req.request_date.strftime('%b %d, %Y') if req.request_date else 'Unknown',
                'original_index': req.donation_id
            })
        
        return jsonify(rejected_list)
    except Exception as e:
        print(f"Error getting rejected requests: {str(e)}")
        return jsonify([])

@app.route('/mark-message-as-sent', methods=['POST'])
def mark_message_as_sent():
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'error': 'Not authorized'})
    
    try:
        data = request.get_json()
        recipient = data.get('recipient')
        message_type = data.get('message_type')
        pet_name = data.get('pet_name')
        content = data.get('content')
        
        # Find user
        user = User.query.filter_by(username=recipient).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'})
        
        # Try to find the right message based on context
        messages = Message.query.filter_by(is_sent=False).all()
        
        for message in messages:
            # Try to find the right message based on context
            if 'Adoption' in message_type:
                if message.adoption_id:
                    adoption_request = AdopterRequest.query.get(message.adoption_id)
                    if adoption_request and adoption_request.user_id == user.user_id:
                        pet = Pet.query.get(adoption_request.pet_id)
                        if pet and pet.pet_name == pet_name:
                            message.content = content
                            message.is_sent = True
                            db.session.commit()
                            return jsonify({'success': True, 'message': 'Message marked as sent'})
            elif 'Rehoming' in message_type:
                if message.donation_id:
                    donation_request = DonationRequest.query.get(message.donation_id)
                    if donation_request and donation_request.user_id == user.user_id:
                        message.content = content
                        message.is_sent = True
                        db.session.commit()
                        return jsonify({'success': True, 'message': 'Message marked as sent'})
        
        # If not found, create a new message
        message = Message(
            content=content,
            message_type=message_type,
            is_sent=True,
            is_read=False
        )
        db.session.add(message)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'New message created and marked as sent'})
    
    except Exception as e:
        db.session.rollback()
        print(f"Error marking message as sent: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get-sent-messages')
def get_sent_messages():
    if not session.get('admin_logged_in'):
        return jsonify([])
    
    try:
        # Get sent messages from database
        sent_messages_db = Message.query.filter_by(is_sent=True).order_by(Message.sent_date.desc()).all()
        
        sent_messages_list = []
        for msg in sent_messages_db:
            # Determine recipient and pet info
            recipient = 'Unknown'
            pet_name = 'No Pet'
            pet_type = 'System'
            
            if msg.adoption_id:
                adoption_request = AdopterRequest.query.get(msg.adoption_id)
                if adoption_request:
                    user = User.query.get(adoption_request.user_id)
                    pet = Pet.query.get(adoption_request.pet_id)
                    recipient = user.username if user else 'Unknown'
                    pet_name = pet.pet_name if pet else 'Unknown'
                    pet_type = pet.pet_type if pet else 'Unknown'
            
            elif msg.donation_id:
                donation_request = DonationRequest.query.get(msg.donation_id)
                if donation_request:
                    user = User.query.get(donation_request.user_id)
                    recipient = user.username if user else 'Unknown'
                    pet_name = 'Multiple Pets'
                    pet_type = 'Various'
            
            sent_messages_list.append({
                'id': msg.message_id,
                'recipient': recipient,
                'type': msg.message_type,
                'pet_name': pet_name,
                'pet_type': pet_type,
                'status': 'Approved' if 'Approval' in msg.message_type else 'Rejected' if 'Rejection' in msg.message_type else 'Info',
                'status_color': '#58CE46' if 'Approval' in msg.message_type else '#ff4444' if 'Rejection' in msg.message_type else '#ff9800',
                'date': msg.sent_date.strftime('%b %d, %Y') if msg.sent_date else 'Unknown',
                'content': msg.content,
                'message_sent': msg.is_sent
            })
        
        return jsonify(sent_messages_list)
    except Exception as e:
        print(f"Error getting sent messages: {str(e)}")
        return jsonify([])

@app.route('/sent')
def sent():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    return render_template('sent.html')

@app.route('/pet-details')
def pet_details():
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    return render_template('pet_details.html')

@app.route('/adopter-details')
def adopter_details():
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    return render_template('adopter_details.html')

# Route to get database stats for admin dashboard
@app.route('/api/dashboard-stats')
def get_dashboard_stats():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Not authorized'})
    
    try:
        total_pets = Pet.query.count()
        adoption_requests_count = AdopterRequest.query.filter_by(status='Pending').count()
        donation_requests_count = DonationRequest.query.filter_by(status='Pending').count()
        total_users = User.query.count()
        approved_adoptions = AdopterRequest.query.filter_by(status='Approved').count()
        rejected_adoptions = AdopterRequest.query.filter_by(status='Rejected').count()
        
        return jsonify({
            'total_pets': total_pets,
            'adoption_requests_count': adoption_requests_count,
            'donation_requests_count': donation_requests_count,
            'total_users': total_users,
            'approved_adoptions': approved_adoptions,
            'rejected_adoptions': rejected_adoptions
        })
    except Exception as e:
        return jsonify({'error': str(e)})

# Route to get all pets for API
@app.route('/api/pets')
def get_all_pets():
    pets = Pet.query.all()
    pets_list = []
    
    for pet in pets:
        pets_list.append({
            'id': pet.pet_id,
            'name': pet.pet_name,
            'type': pet.pet_type,
            'breed': pet.pet_breed,
            'age': pet.pet_age,
            'gender': pet.pet_gender,
            'birthday': pet.pet_bod.strftime('%Y-%m-%d') if pet.pet_bod else None,
            'status': 'Available'
        })
    
    return jsonify(pets_list)

# Route to get adoption requests
@app.route('/api/adoption-requests')
def get_adoption_requests():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Not authorized'})
    
    requests = AdopterRequest.query.all()
    requests_list = []
    
    for req in requests:
        user = User.query.get(req.user_id)
        pet = Pet.query.get(req.pet_id)
        requests_list.append({
            'id': req.adoption_id,
            'user': user.username if user else 'Unknown',
            'pet': pet.pet_name if pet else 'Unknown',
            'pet_type': pet.pet_type if pet else 'Unknown',
            'status': req.status,
            'date': req.request_date.strftime('%Y-%m-%d') if req.request_date else 'Unknown'
        })
    
    return jsonify(requests_list)

# Route to get donation (rehoming) requests
@app.route('/api/donation-requests')
def get_donation_requests():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Not authorized'})
    
    requests = DonationRequest.query.all()
    requests_list = []
    
    for req in requests:
        user = User.query.get(req.user_id)
        requests_list.append({
            'id': req.donation_id,
            'user': user.username if user else 'Unknown',
            'status': req.status,
            'date': req.request_date.strftime('%Y-%m-%d') if req.request_date else 'Unknown'
        })
    
    return jsonify(requests_list)

# Route to get all users
@app.route('/api/users')
def get_users():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Not authorized'})
    
    users = User.query.all()
    users_list = []
    
    for user in users:
        users_list.append({
            'id': user.user_id,
            'username': user.username,
            'type': user.user_type
        })
    
    return jsonify(users_list)

# API route to get detailed pet data for view_pets.html modal
@app.route('/api/pet-details/<pet_id>')
def get_pet_details(pet_id):
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Not authorized'})
    
    try:
        pet = Pet.query.get(int(pet_id))
        if not pet:
            return jsonify({'error': 'Pet not found'})
        
        # Get medical records
        vaccines = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Vaccine').order_by(PetMedical.date).all()
        deworming = PetMedical.query.filter_by(pet_id=pet.pet_id, medical_type='Deworming').order_by(PetMedical.date).all()
        
        # Get adoption request if exists
        adoption_request = AdopterRequest.query.filter_by(pet_id=pet.pet_id).first()
        
        # Get owner info
        owner_info = None
        if adoption_request:
            adopter_detail = AdopterDetails.query.filter_by(adoption_id=adoption_request.adoption_id).first()
            if adopter_detail:
                person = Person.query.get(adopter_detail.person_id)
                if person:
                    owner_info = {
                        'name': person.full_name,
                        'age': f"{person.age} years old",
                        'address': person.address,
                        'email': person.email,
                        'contact': person.phone_number,
                        'employmentStatus': adopter_detail.employment_status,
                        'profession': adopter_detail.profession,
                        'employmentHistory': adopter_detail.employment_history
                    }
        
        # Prepare response
        response = {
            'name': pet.pet_name,
            'type': pet.pet_type,
            'age': f"{pet.pet_age} months old" if pet.pet_age else "Unknown",
            'gender': 'Male' if pet.pet_gender == 'M' else 'Female' if pet.pet_gender == 'F' else 'Unknown',
            'breed': pet.pet_breed,
            'birthday': pet.pet_bod.strftime('%m/%d/%Y') if pet.pet_bod else 'Unknown',
            'vaccineType': vaccines[0].name if vaccines else 'Not specified',
            'firstVaccine': vaccines[0].date.strftime('%m/%d/%Y') if vaccines else 'Not specified',
            'latestVaccine': vaccines[-1].date.strftime('%m/%d/%Y') if vaccines else 'Not specified',
            'dewormerType': deworming[0].name if deworming else 'Not specified',
            'firstDeworming': deworming[0].date.strftime('%m/%d/%Y') if deworming else 'Not specified',
            'latestDeworming': deworming[-1].date.strftime('%m/%d/%Y') if deworming else 'Not specified',
            'reason': adoption_request.status if adoption_request else 'Available for adoption',
            'owner': owner_info
        }
        
        return jsonify(response)
    
    except Exception as e:
        print(f"Error getting pet details: {str(e)}")
        return jsonify({'error': str(e)})

# API route to delete a pet
@app.route('/api/delete-pet/<pet_id>', methods=['DELETE'])
def delete_pet(pet_id):
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'error': 'Not authorized'})
    
    try:
        pet = Pet.query.get(int(pet_id))
        if not pet:
            return jsonify({'success': False, 'error': 'Pet not found'})
        
        # Delete related records first
        PetMedical.query.filter_by(pet_id=pet.pet_id).delete()
        AdopterRequest.query.filter_by(pet_id=pet.pet_id).delete()
        
        # Delete the pet
        db.session.delete(pet)
        db.session.commit()
        
        return jsonify({'success': True, 'message': f'Pet {pet.pet_name} deleted successfully'})
    
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting pet: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    # Create database tables if they don't exist
    with app.app_context():
        db.create_all()
        print("=" * 50)
        print("BESTO FRIENDO Application")
        print("Database initialized successfully!")
        print("=" * 50)
    
    app.run(debug=True, port=5000)