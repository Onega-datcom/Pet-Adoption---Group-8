from flask import Flask, render_template, url_for, request, redirect, session, flash, jsonify
import os
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Hardcoded admin credentials
ADMIN_USERNAME = "Admin1"
ADMIN_PASSWORD = "adminpass"

# Sample data for requests - ONLY 3 ENTRIES EACH
ADOPTION_REQUESTS = [
    {'name': 'Jacey Hernandez', 'date': 'Dec 8, 2025', 'status': 'Pending', 'new': True, 'pet_key': 'jacey', 'pet_name': 'Leo', 'pet_type': 'Cat'},
    {'name': 'Stephanie Sales', 'date': 'Dec 6, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'stephanie', 'pet_name': 'Theo', 'pet_type': 'Dog'},
    {'name': 'Megan Stuart', 'date': 'Dec 5, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'megan', 'pet_name': 'Hailey', 'pet_type': 'Dog'},
]

REHOMING_REQUESTS = [
    {'name': 'Emily Brown', 'date': 'Dec 7, 2025', 'status': 'Pending', 'new': True, 'pet_key': 'emily', 'pet_name': 'Bella', 'pet_type': 'Cat'},
    {'name': 'Robert Smith', 'date': 'Dec 5, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'robert', 'pet_name': 'Max', 'pet_type': 'Dog'},
    {'name': 'Sarah Johnson', 'date': 'Dec 4, 2025', 'status': 'Pending', 'new': False, 'pet_key': 'sarah', 'pet_name': 'Luna', 'pet_type': 'Cat'},
]

# Pet details data
PET_DATA = {
    'jacey': {
        'title': "Want to Adopt:",
        'name': "Leo",
        'type': "Cat",
        'age': "6 months old",
        'gender': "M",
        'breed': "Siamese",
        'birthday': "06/15/2025",
        'vaccineType': "FVRCP",
        'firstVaccine': "09/01/2025",
        'latestVaccine': "12/01/2025",
        'dewormerType': "Pyramid Pamoate",
        'firstDeworming': "08/01/2025",
        'latestDeworming': "11/01/2025",
        'reason': "Allergies in the family",
        'images': ['leo1.png', 'leo2.png', 'leo3.png', 'leo4.png'],
        'owner': {
            'name': "Jacey Hernandez",
            'age': "28",
            'address': "1234 Maple Street, Manila, Philippines",
            'email': "jacey.hernandez@email.com",
            'contact': "+63 912 345 6789"
        }
    },
    'stephanie': {
        'title': "Want to Adopt:",
        'name': "Theo",
        'type': "Dog",
        'age': "3 months old",
        'gender': "M",
        'breed': "Corgi",
        'birthday': "09/10/2025",
        'vaccineType': "DHPP",
        'firstVaccine': "10/15/2025",
        'latestVaccine': "12/05/2025",
        'dewormerType': "Fenbendazole",
        'firstDeworming': "10/01/2025",
        'latestDeworming': "11/25/2025",
        'reason': "Moving to a pet-free apartment",
        'images': ['theo1.png', 'theo2.png', 'theo3.png', 'theo4.png'],
        'owner': {
            'name': "Stephanie Sales",
            'age': "32",
            'address': "5678 Oak Avenue, Quezon City, Philippines",
            'email': "stephanie.sales@email.com",
            'contact': "+63 917 890 1234"
        }
    },
    'megan': {
        'title': "Want to Adopt:",
        'name': "Hailey",
        'type': "Dog",
        'age': "2 months old",
        'gender': "F",
        'breed': "Maltese",
        'birthday': "10/05/2025",
        'vaccineType': "DHPP",
        'firstVaccine': "11/10/2025",
        'latestVaccine': "12/08/2025",
        'dewormerType': "Pyrantel Pamoate",
        'firstDeworming': "11/01/2025",
        'latestDeworming': "12/01/2025",
        'reason': "Financial constraints",
        'images': ['hailey1.png', 'hailey2.png', 'hailey3.png', 'hailey4.png'],
        'owner': {
            'name': "Megan Stuart",
            'age': "25",
            'address': "91011 Pine Road, Makati, Philippines",
            'email': "megan.stuart@email.com",
            'contact': "+63 918 456 7890"
        }
    },
    'emily': {
        'title': "Want to Adopt:",
        'name': "Bella",
        'type': "Cat",
        'age': "1 year old",
        'gender': "F",
        'breed': "Scottish Fold",
        'birthday': "12/10/2024",
        'vaccineType': "FVRCP",
        'firstVaccine': "02/15/2025",
        'latestVaccine': "11/20/2025",
        'dewormerType': "Pyramid Pamoate",
        'firstDeworming': "01/20/2025",
        'latestDeworming': "10/15/2025",
        'reason': "Owner traveling frequently for work",
        'images': ['bella1.png', 'bella2.png', 'bella3.png', 'bella4.png'],
        'owner': {
            'name': "Emily Brown",
            'age': "31",
            'address': "1819 Spruce Street, Pasig, Philippines",
            'email': "emily.brown@email.com",
            'contact': "+63 922 345 6789"
        }
    },
    'robert': {
        'title': "Want to Adopt:",
        'name': "Max",
        'type': "Dog",
        'age': "3 years old",
        'gender': "M",
        'breed': "German Shepherd",
        'birthday': "11/15/2022",
        'vaccineType': "DHPP",
        'firstVaccine': "01/20/2023",
        'latestVaccine': "10/25/2025",
        'dewormerType': "Fenbendazole",
        'firstDeworming': "12/20/2022",
        'latestDeworming': "09/30/2025",
        'reason': "Owner relocating to a smaller home",
        'images': ['max1.png', 'max2.png', 'max3.png', 'max4.png'],
        'owner': {
            'name': "Robert Smith",
            'age': "45",
            'address': "2021 Redwood Drive, Mandaluyong, Philippines",
            'email': "robert.smith@email.com",
            'contact': "+63 923 456 7890"
        }
    },
    'sarah': {
        'title': "Want to Adopt:",
        'name': "Luna",
        'type': "Cat",
        'age': "1.5 years old",
        'gender': "F",
        'breed': "British Shorthair",
        'birthday': "06/15/2024",
        'vaccineType': "FVRCP",
        'firstVaccine': "08/01/2024",
        'latestVaccine': "11/15/2025",
        'dewormerType': "Pyrantel Pamoate",
        'firstDeworming': "07/15/2024",
        'latestDeworming': "10/30/2025",
        'reason': "Owner moving abroad",
        'images': ['luna1.png', 'luna2.png', 'luna3.png', 'luna4.png'],
        'owner': {
            'name': "Sarah Johnson",
            'age': "28",
            'address': "2223 Willow Road, Pasig, Philippines",
            'email': "sarah.johnson@email.com",
            'contact': "+63 922 789 0123"
        }
    },
    'halley': {
        'name': "Halley",
        'type': "Dog",
        'age': "2 years old",
        'gender': "F",
        'breed': "Maltese",
        'birthday': "01/25/2023",
        'vaccineType': "DHPP (Distemper/Parvo) and Rabies",
        'firstVaccine': "05/25/2023",
        'latestVaccine': "11/01/2025",
        'dewormerType': "Broad-Spectrum Chew",
        'firstDeworming': "04/08/2023",
        'latestDeworming': "10/01/2025",
        'reason': "Allergies in the family",
        'owner': {
            'name': "Lucas Reyes",
            'age': "30",
            'address': "Taal, Batangas",
            'email': "lucasreyes@gmail.com",
            'contact': "09231242143"
        }
    }
}

# Additional pets for View Pets page
ADDITIONAL_PETS = {
    'lia': {'name': "Lia", 'type': "Cat", 'breed': "Ragdoll", 'age': "8 months old"},
    'kabel': {'name': "Kabel", 'type': "Cat", 'breed': "Puspin", 'age': "1 year old"},
    'znowy': {'name': "Znowy", 'type': "Cat", 'breed': "Ragdoll", 'age': "9 months old"},
    'oreo': {'name': "Oreo", 'type': "Cat", 'breed': "Siamese", 'age': "2 years old"},
    'asher': {'name': "Asher", 'type': "Cat", 'breed': "Puspin", 'age': "1.5 years old"}
}

# Adopter details data
ADOPTER_DATA = {
    'jacey': {
        'name': "Jacey Hernandez",
        'age': "28 years old",
        'address': "1234 Maple Street, Manila, Philippines",
        'email': "jacey.hernandez@email.com",
        'contact': "+63 912 345 6789",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Software Engineer",
        'employer': "Tech Solutions Inc.",
        'idType': "Driver's License"
    },
    'stephanie': {
        'name': "Stephanie Sales",
        'age': "32 years old",
        'address': "5678 Oak Avenue, Quezon City, Philippines",
        'email': "stephanie.sales@email.com",
        'contact': "+63 917 890 1234",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Marketing Manager",
        'employer': "Creative Solutions Corp.",
        'idType': "Passport"
    },
    'megan': {
        'name': "Megan Stuart",
        'age': "25 years old",
        'address': "91011 Pine Road, Makati, Philippines",
        'email': "megan.stuart@email.com",
        'contact': "+63 918 456 7890",
        'employmentStatus': "Employed Part-time",
        'jobTitle': "Graphic Designer",
        'employer': "Design Studio Co.",
        'idType': "Driver's License"
    },
    'emily': {
        'name': "Emily Brown",
        'age': "31 years old",
        'address': "1819 Spruce Street, Pasig, Philippines",
        'email': "emily.brown@email.com",
        'contact': "+63 922 345 6789",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Flight Attendant",
        'employer': "Sky Airlines",
        'idType': "Passport"
    },
    'robert': {
        'name': "Robert Smith",
        'age': "45 years old",
        'address': "2021 Redwood Drive, Mandaluyong, Philippines",
        'email': "robert.smith@email.com",
        'contact': "+63 923 456 7890",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Architect",
        'employer': "Urban Design Associates",
        'idType': "Professional ID"
    },
    'sarah': {
        'name': "Sarah Johnson",
        'age': "28 years old",
        'address': "2223 Willow Road, Pasig, Philippines",
        'email': "sarah.johnson@email.com",
        'contact': "+63 922 789 0123",
        'employmentStatus': "Employed Full-time",
        'jobTitle': "Marketing Director",
        'employer': "Digital Marketing Inc.",
        'idType': "Driver's License"
    }
}

# Global lists to track approved and rejected requests
APPROVED_REQUESTS = []
REJECTED_REQUESTS = []
SENT_MESSAGES = []

# Counter for sent message IDs - define it globally
MESSAGE_ID_COUNTER = 1

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        # Check if it's admin login
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            session['username'] = username
            return redirect(url_for('admin_panel'))
        else:
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/admin-logout')
def admin_logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/admin-panel')
def admin_panel():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    return render_template('admin_panel.html', 
                         adoption_requests=ADOPTION_REQUESTS,
                         rehoming_requests=REHOMING_REQUESTS,
                         pet_data=json.dumps(PET_DATA),
                         adopter_data=json.dumps(ADOPTER_DATA))

@app.route('/view-pets')
def view_pets():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    # Create pet data for the table view
    pets_list = []
    
    # Add all pets from PET_DATA dictionary
    for key, pet in PET_DATA.items():
        if 'owner' in pet:
            pet_with_key = pet.copy()
            pet_with_key['key'] = key
            pets_list.append(pet_with_key)
    
    # Add additional pets
    for key, pet in ADDITIONAL_PETS.items():
        pet_with_key = pet.copy()
        pet_with_key['key'] = key
        pets_list.append(pet_with_key)
    
    return render_template('view_pets.html', pets=pets_list)

@app.route('/compose')
def compose():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    return render_template('compose.html', 
                         approved_requests=APPROVED_REQUESTS,
                         rejected_requests=REJECTED_REQUESTS)

@app.route('/update-request-status', methods=['POST'])
def update_request_status():
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'error': 'Not authorized'})
    
    data = request.get_json()
    request_type = data.get('type')  # 'adoption' or 'rehoming'
    request_index = int(data.get('index'))
    status = data.get('status')  # 'accepted' or 'rejected'
    pet_key = data.get('pet_key')
    requester_name = data.get('requester_name')
    
    try:
        # Declare global at the beginning of the function
        global MESSAGE_ID_COUNTER
        
        # Update the status in the appropriate requests list
        if request_type == 'adoption' and 0 <= request_index < len(ADOPTION_REQUESTS):
            # Update the status in the original list
            ADOPTION_REQUESTS[request_index]['status'] = status.capitalize()
            pet_name = ADOPTION_REQUESTS[request_index]['pet_name']
            pet_type = ADOPTION_REQUESTS[request_index]['pet_type']
            date = ADOPTION_REQUESTS[request_index]['date']
            
            # Create request data for compose page
            request_data = {
                'type': request_type,
                'name': requester_name,
                'pet_name': pet_name,
                'pet_type': pet_type,
                'status': status.capitalize(),
                'date': date,
                'original_index': request_index
            }
            
            # Add to appropriate global list
            if status == 'accepted':
                # Remove if already exists to avoid duplicates
                APPROVED_REQUESTS[:] = [req for req in APPROVED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                APPROVED_REQUESTS.append(request_data)
                # Remove from rejected list if it was there
                REJECTED_REQUESTS[:] = [req for req in REJECTED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
            elif status == 'rejected':
                # Remove if already exists to avoid duplicates
                REJECTED_REQUESTS[:] = [req for req in REJECTED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                REJECTED_REQUESTS.append(request_data)
                # Remove from approved list if it was there
                APPROVED_REQUESTS[:] = [req for req in APPROVED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                
            # Create sent message record (marked as not sent yet)
            sent_message = {
                'id': MESSAGE_ID_COUNTER,
                'recipient': requester_name,
                'type': f'Adoption {"Approval" if status == "accepted" else "Rejection"}',
                'pet_name': pet_name,
                'pet_type': pet_type,
                'status': status.capitalize(),
                'status_color': '#58CE46' if status == 'accepted' else '#ff4444',
                'date': datetime.now().strftime('%b %d, %Y'),
                'content': '',  # Will be filled when message is actually sent
                'message_sent': False  # Track if message was actually sent from Compose
            }
            SENT_MESSAGES.append(sent_message)
            MESSAGE_ID_COUNTER += 1
            
            return jsonify({'success': True, 'message': f'Adoption request {status}'})
            
        elif request_type == 'rehoming' and 0 <= request_index < len(REHOMING_REQUESTS):
            # Update the status in the original list
            REHOMING_REQUESTS[request_index]['status'] = status.capitalize()
            
            # Get pet details from PET_DATA for rehoming
            pet_data = PET_DATA.get(pet_key, {})
            pet_name = pet_data.get('name', 'Unknown')
            pet_type = pet_data.get('type', 'Unknown')
            date = REHOMING_REQUESTS[request_index]['date']
            
            # Create request data for compose page
            request_data = {
                'type': request_type,
                'name': requester_name,
                'pet_name': pet_name,
                'pet_type': pet_type,
                'status': status.capitalize(),
                'date': date,
                'original_index': request_index
            }
            
            # Add to appropriate global list
            if status == 'accepted':
                # Remove if already exists to avoid duplicates
                APPROVED_REQUESTS[:] = [req for req in APPROVED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                APPROVED_REQUESTS.append(request_data)
                # Remove from rejected list if it was there
                REJECTED_REQUESTS[:] = [req for req in REJECTED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
            elif status == 'rejected':
                # Remove if already exists to avoid duplicates
                REJECTED_REQUESTS[:] = [req for req in REJECTED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                REJECTED_REQUESTS.append(request_data)
                # Remove from approved list if it was there
                APPROVED_REQUESTS[:] = [req for req in APPROVED_REQUESTS 
                                       if not (req['name'] == requester_name and req['pet_name'] == pet_name and req['type'] == request_type)]
                
            # Create sent message record (marked as not sent yet)
            sent_message = {
                'id': MESSAGE_ID_COUNTER,
                'recipient': requester_name,
                'type': f'Rehoming {"Approval" if status == "accepted" else "Rejection"}',
                'pet_name': pet_name,
                'pet_type': pet_type,
                'status': status.capitalize(),
                'status_color': '#58CE46' if status == 'accepted' else '#ff4444',
                'date': datetime.now().strftime('%b %d, %Y'),
                'content': '',  # Will be filled when message is actually sent
                'message_sent': False  # Track if message was actually sent from Compose
            }
            SENT_MESSAGES.append(sent_message)
            MESSAGE_ID_COUNTER += 1
                
            return jsonify({'success': True, 'message': f'Rehoming request {status}'})
        
        return jsonify({'success': False, 'error': 'Invalid request index'})
    
    except Exception as e:
        print(f"Error updating request status: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get-approved-requests')
def get_approved_requests():
    try:
        return jsonify(APPROVED_REQUESTS)
    except Exception as e:
        print(f"Error getting approved requests: {str(e)}")
        return jsonify([])

@app.route('/get-rejected-requests')
def get_rejected_requests():
    try:
        return jsonify(REJECTED_REQUESTS)
    except Exception as e:
        print(f"Error getting rejected requests: {str(e)}")
        return jsonify([])

@app.route('/mark-message-as-sent', methods=['POST'])
def mark_message_as_sent():
    if not session.get('admin_logged_in'):
        return jsonify({'success': False, 'error': 'Not authorized'})
    
    try:
        data = request.get_json()
        recipient = data.get('recipient')
        message_type = data.get('message_type')
        pet_name = data.get('pet_name')
        content = data.get('content')
        
        # Declare global at the beginning of the function
        global MESSAGE_ID_COUNTER
        
        # Find the message in SENT_MESSAGES and update it
        for message in SENT_MESSAGES:
            if (message['recipient'] == recipient and 
                message['pet_name'] == pet_name and
                message['type'] == message_type and
                not message['message_sent']):
                
                message['content'] = content
                message['message_sent'] = True
                message['date'] = datetime.now().strftime('%b %d, %Y')
                
                # Also update the request status to show it's been processed
                # Find and update the corresponding approved/rejected request
                if 'Approval' in message_type:
                    # Remove from approved requests since message has been sent
                    APPROVED_REQUESTS[:] = [req for req in APPROVED_REQUESTS 
                                           if not (req['name'] == recipient and req['pet_name'] == pet_name)]
                elif 'Rejection' in message_type:
                    # Remove from rejected requests since message has been sent
                    REJECTED_REQUESTS[:] = [req for req in REJECTED_REQUESTS 
                                           if not (req['name'] == recipient and req['pet_name'] == pet_name)]
                
                return jsonify({'success': True, 'message': 'Message marked as sent'})
        
        # If not found, create a new sent message
        sent_message = {
            'id': MESSAGE_ID_COUNTER,
            'recipient': recipient,
            'type': message_type,
            'pet_name': pet_name,
            'pet_type': data.get('pet_type', 'Unknown'),
            'status': 'Approved' if 'Approval' in message_type else 'Rejected',
            'status_color': '#58CE46' if 'Approval' in message_type else '#ff4444',
            'date': datetime.now().strftime('%b %d, %Y'),
            'content': content,
            'message_sent': True
        }
        SENT_MESSAGES.append(sent_message)
        MESSAGE_ID_COUNTER += 1
        
        return jsonify({'success': True, 'message': 'New message created and marked as sent'})
    
    except Exception as e:
        print(f"Error marking message as sent: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get-sent-messages')
def get_sent_messages():
    if not session.get('admin_logged_in'):
        return jsonify([])
    
    try:
        # Only return messages that have been marked as sent
        sent_only = [msg for msg in SENT_MESSAGES if msg.get('message_sent', False)]
        return jsonify(sent_only)
    except Exception as e:
        print(f"Error getting sent messages: {str(e)}")
        return jsonify([])

@app.route('/sent')
def sent():
    # Check if admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    
    return render_template('sent.html')

@app.route('/pet-details')
def pet_details():
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    return render_template('pet_details.html')

@app.route('/adopter-details')
def adopter_details():
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
    return render_template('adopter_details.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)