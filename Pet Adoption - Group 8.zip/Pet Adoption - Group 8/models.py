#!/usr/bin/env python3
"""
Database models for BESTO FRIENDO application.
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import base64

db = SQLAlchemy()

class Person(db.Model):
    __tablename__ = 'person'
    
    person_id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer)
    address = db.Column(db.String(100))
    email = db.Column(db.String(100))
    phone_number = db.Column(db.String(11))
    valid_image = db.Column(db.LargeBinary)
    
    # Relationships
    adopter_details = db.relationship('AdopterDetails', backref='person', cascade='all, delete-orphan')
    donation_details_users = db.relationship('DonationDetailsUser', backref='person', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'person_id': self.person_id,
            'full_name': self.full_name,
            'age': self.age,
            'address': self.address,
            'email': self.email,
            'phone_number': self.phone_number,
            'valid_image': base64.b64encode(self.valid_image).decode('utf-8') if self.valid_image else None
        }

class AdopterDetails(db.Model):
    __tablename__ = 'adopter_details'
    
    adopter_details_id = db.Column(db.Integer, primary_key=True)
    adoption_id = db.Column(db.Integer, db.ForeignKey('adopter_request.adoption_id'))
    person_id = db.Column(db.Integer, db.ForeignKey('person.person_id'), nullable=False)
    employment_status = db.Column(db.String(50))
    profession = db.Column(db.String(50))
    employment_history = db.Column(db.String(50))
    
    # Relationship with AdopterRequest
    adopter_request = db.relationship('AdopterRequest', backref='adopter_detail')
    
    def to_dict(self):
        return {
            'adopter_details_id': self.adopter_details_id,
            'adoption_id': self.adoption_id,
            'person_id': self.person_id,
            'employment_status': self.employment_status,
            'profession': self.profession,
            'employment_history': self.employment_history,
            'person': self.person.to_dict() if self.person else None
        }

class DonationDetailsUser(db.Model):
    __tablename__ = 'donation_details_user'
    
    donation_details_id = db.Column(db.Integer, primary_key=True)
    donation_id = db.Column(db.Integer, db.ForeignKey('donation_request.donation_id'))
    person_id = db.Column(db.Integer, db.ForeignKey('person.person_id'), nullable=False)
    
    def to_dict(self):
        return {
            'donation_details_id': self.donation_details_id,
            'donation_id': self.donation_id,
            'person_id': self.person_id,
            'person': self.person.to_dict() if self.person else None
        }

class Pet(db.Model):
    __tablename__ = 'pet'
    
    pet_id = db.Column(db.Integer, primary_key=True)
    pet_name = db.Column(db.String(50))
    pet_type = db.Column(db.String(50))
    pet_age = db.Column(db.Integer)
    pet_gender = db.Column(db.String(1))
    pet_breed = db.Column(db.String(50))
    pet_bod = db.Column(db.Date)
    pet_image = db.Column(db.LargeBinary)
    
    # Relationships
    medical_records = db.relationship('PetMedical', backref='pet', cascade='all, delete-orphan')
    adoption_requests = db.relationship('AdopterRequest', backref='pet', cascade='all, delete-orphan')
    donation_pets = db.relationship('DonationDetailsPet', backref='pet', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'pet_id': self.pet_id,
            'pet_name': self.pet_name,
            'pet_type': self.pet_type,
            'pet_age': self.pet_age,
            'pet_gender': self.pet_gender,
            'pet_breed': self.pet_breed,
            'pet_bod': self.pet_bod.strftime('%Y-%m-%d') if self.pet_bod else None,
            'pet_image': base64.b64encode(self.pet_image).decode('utf-8') if self.pet_image else None,
            'medical_records': [record.to_dict() for record in self.medical_records]
        }

class PetMedical(db.Model):
    __tablename__ = 'pet_medical'
    
    pet_medical_id = db.Column(db.Integer, primary_key=True)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.pet_id'), nullable=False)
    medical_type = db.Column(db.String(50))
    name = db.Column(db.String(50))
    date = db.Column(db.Date)
    
    def to_dict(self):
        return {
            'pet_medical_id': self.pet_medical_id,
            'pet_id': self.pet_id,
            'medical_type': self.medical_type,
            'name': self.name,
            'date': self.date.strftime('%Y-%m-%d') if self.date else None
        }

class DonationDetailsPet(db.Model):
    __tablename__ = 'donation_details_pet'
    
    donation_pet_id = db.Column(db.Integer, primary_key=True)
    donation_details_id = db.Column(db.Integer, db.ForeignKey('donation_details_user.donation_details_id'))
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.pet_id'))
    adoption_reason = db.Column(db.Text)
    
    # Relationships
    donation_details_user = db.relationship('DonationDetailsUser', backref='donation_pets')
    medical_records = db.relationship('DonationPetMedical', backref='donation_pet', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'donation_pet_id': self.donation_pet_id,
            'donation_details_id': self.donation_details_id,
            'pet_id': self.pet_id,
            'adoption_reason': self.adoption_reason,
            'pet': self.pet.to_dict() if self.pet else None,
            'medical_records': [record.to_dict() for record in self.medical_records]
        }

class DonationPetMedical(db.Model):
    __tablename__ = 'donation_pet_medical'
    
    donation_pet_medical_id = db.Column(db.Integer, primary_key=True)
    donation_pet_id = db.Column(db.Integer, db.ForeignKey('donation_details_pet.donation_pet_id'), nullable=False)
    medical_type = db.Column(db.String(50))
    name = db.Column(db.String(50))
    date = db.Column(db.Date)
    
    def to_dict(self):
        return {
            'donation_pet_medical_id': self.donation_pet_medical_id,
            'donation_pet_id': self.donation_pet_id,
            'medical_type': self.medical_type,
            'name': self.name,
            'date': self.date.strftime('%Y-%m-%d') if self.date else None
        }

class User(db.Model):
    __tablename__ = 'user'
    
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), default='regular')  # 'admin' or 'regular'
    
    # Relationships
    adoption_requests = db.relationship('AdopterRequest', backref='user', cascade='all, delete-orphan')
    donation_requests = db.relationship('DonationRequest', backref='user', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'username': self.username,
            'user_type': self.user_type
        }

class AdopterRequest(db.Model):
    __tablename__ = 'adopter_request'
    
    adoption_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), nullable=False)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.pet_id'), nullable=False)
    status = db.Column(db.String(20), default='Pending')  # Pending, Approved, Rejected
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    processed_date = db.Column(db.DateTime)
    
    # Relationship with Message
    messages = db.relationship('Message', backref='adoption_request')
    
    def to_dict(self):
        return {
            'adoption_id': self.adoption_id,
            'user_id': self.user_id,
            'pet_id': self.pet_id,
            'status': self.status,
            'request_date': self.request_date.strftime('%Y-%m-%d %H:%M:%S') if self.request_date else None,
            'processed_date': self.processed_date.strftime('%Y-%m-%d %H:%M:%S') if self.processed_date else None,
            'user': self.user.to_dict() if self.user else None,
            'pet': self.pet.to_dict() if self.pet else None
        }

class DonationRequest(db.Model):
    __tablename__ = 'donation_request'
    
    donation_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), nullable=False)
    status = db.Column(db.String(20), default='Pending')  # Pending, Approved, Rejected
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    processed_date = db.Column(db.DateTime)
    
    # Relationships
    donation_details_users = db.relationship('DonationDetailsUser', backref='donation_request', cascade='all, delete-orphan')
    messages = db.relationship('Message', backref='donation_request')
    
    def to_dict(self):
        return {
            'donation_id': self.donation_id,
            'user_id': self.user_id,
            'status': self.status,
            'request_date': self.request_date.strftime('%Y-%m-%d %H:%M:%S') if self.request_date else None,
            'processed_date': self.processed_date.strftime('%Y-%m-%d %H:%M:%S') if self.processed_date else None,
            'user': self.user.to_dict() if self.user else None,
            'donation_details': [detail.to_dict() for detail in self.donation_details_users]
        }

class Message(db.Model):
    __tablename__ = 'message'
    
    message_id = db.Column(db.Integer, primary_key=True)
    adoption_id = db.Column(db.Integer, db.ForeignKey('adopter_request.adoption_id'))
    donation_id = db.Column(db.Integer, db.ForeignKey('donation_request.donation_id'))
    content = db.Column(db.Text, nullable=False)
    message_type = db.Column(db.String(50))  # Approval, Rejection, Info
    sent_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_sent = db.Column(db.Boolean, default=False)
    is_read = db.Column(db.Boolean, default=False)
    
    def to_dict(self):
        return {
            'message_id': self.message_id,
            'adoption_id': self.adoption_id,
            'donation_id': self.donation_id,
            'content': self.content,
            'message_type': self.message_type,
            'sent_date': self.sent_date.strftime('%Y-%m-%d %H:%M:%S') if self.sent_date else None,
            'is_sent': self.is_sent,
            'is_read': self.is_read
        }